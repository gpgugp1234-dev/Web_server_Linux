using SafeStockManager.Web.Models;
using SafeStockManager.Web.Repositories;
using System.Text.RegularExpressions;

namespace SafeStockManager.Web.Services;

public sealed class InventoryAppService
{
    private readonly InventoryRepository _repository;
    private readonly AlertService _alertService;
    private readonly IConfiguration _configuration;

    public InventoryAppService(
        InventoryRepository repository,
        AlertService alertService,
        IConfiguration configuration)
    {
        _repository = repository;
        _alertService = alertService;
        _configuration = configuration;
    }

    public List<InventoryListItem> GetInventoryItems(bool includeInactive = false)
    {
        var items = _repository.GetInventoryItems(includeInactive);
        foreach (var item in items)
        {
            item.IsLongNotChecked = _alertService.IsLongNotChecked(item.LastCheckedAt);
        }

        return items;
    }

    public DashboardSummary GetSummary(IEnumerable<InventoryListItem> items)
        => _alertService.BuildSummary(items);

    public List<LookupItem> GetCategories() => _repository.GetCategories();
    public List<LookupItem> GetUnits() => _repository.GetUnits();
    public List<Inspector> GetInspectors(bool includeInactive = false) => _repository.GetInspectors(includeInactive);
    public List<InventoryHistoryItem> GetHistory(int itemId) => _repository.GetHistory(itemId);
    public ItemEditorModel? GetItemEditorModel(int itemId) => _repository.GetItemEditorModel(itemId);

    public InventoryHistoryItem? GetLatestHistory(int itemId)
        => _repository.GetHistory(itemId)
            .OrderByDescending(x => x.ActionDate)
            .FirstOrDefault();

    public bool ValidateAdjustmentPin(string pin)
    {
        pin = (pin ?? string.Empty).Trim();

        if (!Regex.IsMatch(pin, @"^\d{8}$"))
            return false;

        var configured = (_configuration["AdjustmentSecurity:PinCode"] ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(configured))
            return false;

        return pin == configured;
    }

    public void SaveItem(ItemEditorModel model, string actor)
    {
        ValidateItem(model);
        _repository.SaveItem(model, actor);
    }

    public void AdjustStock(StockAdjustmentModel model)
    {
        if (model.NewCurrentQty < 0)
            throw new InvalidOperationException("현재고는 0 이상이어야 합니다.");

        if (model.NewExcludedQty < 0)
            throw new InvalidOperationException("제외수량은 0 이상이어야 합니다.");

        if (string.IsNullOrWhiteSpace(model.Reason))
            throw new InvalidOperationException("재고 보정 사유를 입력해 주세요.");

        if (string.IsNullOrWhiteSpace(model.CheckedBy))
            throw new InvalidOperationException("조사자를 선택해 주세요.");

        _repository.AdjustStock(model, _alertService);
    }

    public void ConfirmCheck(CheckConfirmModel model)
    {
        if (model.ItemIds.Count == 0)
            throw new InvalidOperationException("확인할 품목을 선택해 주세요.");

        if (string.IsNullOrWhiteSpace(model.CheckedBy))
            throw new InvalidOperationException("조사자를 선택해 주세요.");

        if (string.IsNullOrWhiteSpace(model.Reason))
            throw new InvalidOperationException("조사 사유를 입력해 주세요.");

        _repository.ConfirmCheck(model);
    }

    public void SetItemActive(int itemId, bool isActive, string actor)
    {
        _repository.SetItemActive(itemId, isActive, actor);
    }

    public void SaveInspector(Inspector inspector)
    {
        if (string.IsNullOrWhiteSpace(inspector.InspectorName))
            throw new InvalidOperationException("조사자 이름을 입력해 주세요.");

        _repository.SaveInspector(inspector);
    }

    private void ValidateItem(ItemEditorModel model)
    {
        if (string.IsNullOrWhiteSpace(model.ItemName))
            throw new InvalidOperationException("품목명은 필수입니다.");

        if (model.CategoryId <= 0)
            throw new InvalidOperationException("분류를 선택해 주세요.");

        if (model.UnitId <= 0)
            throw new InvalidOperationException("단위를 선택해 주세요.");

        if (model.SafetyStock < 0)
            throw new InvalidOperationException("안전재고는 0 이상이어야 합니다.");

        if (model.AlertBufferQty < 0)
            throw new InvalidOperationException("알림 여유수량은 0 이상이어야 합니다.");
    }
}
