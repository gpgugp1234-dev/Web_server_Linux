namespace SafeStockManager.Web.Services;

public sealed class AdjustmentUnlockState
{
    public bool IsUnlocked { get; private set; }

    public void Unlock() => IsUnlocked = true;
    public void Lock() => IsUnlocked = false;
}
