using SafeStockManager.Web.Models;

namespace SafeStockManager.Web.Services;

public sealed class AlertService
{
    public string DetermineStatus(int usableQty, int safetyStock, int alertBufferQty)
    {
        if (usableQty <= 0)
        {
            return "품절";
        }

        if (usableQty <= safetyStock)
        {
            return "긴급";
        }

        if (usableQty <= safetyStock + alertBufferQty)
        {
            return "주의";
        }

        return "정상";
    }

    public bool IsLongNotChecked(DateTime? lastCheckedAt, int overdueDays = 30)
    {
        if (lastCheckedAt is null)
        {
            return true;
        }

        return (DateTime.Today - lastCheckedAt.Value.Date).TotalDays > overdueDays;
    }

    public DashboardSummary BuildSummary(IEnumerable<InventoryListItem> items)
    {
        var list = items.Where(x => x.IsActive).ToList();

        return new DashboardSummary
        {
            TotalCount = list.Count,
            NormalCount = list.Count(x => x.StatusCode == "정상"),
            WarningCount = list.Count(x => x.StatusCode == "주의"),
            CriticalCount = list.Count(x => x.StatusCode == "긴급"),
            OutOfStockCount = list.Count(x => x.StatusCode == "품절"),
            LongNotCheckedCount = list.Count(x => x.IsLongNotChecked)
        };
    }
}
