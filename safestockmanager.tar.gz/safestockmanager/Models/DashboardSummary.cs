namespace SafeStockManager.Web.Models;

public sealed class DashboardSummary
{
    public int TotalCount { get; set; }
    public int NormalCount { get; set; }
    public int WarningCount { get; set; }
    public int CriticalCount { get; set; }
    public int OutOfStockCount { get; set; }
    public int LongNotCheckedCount { get; set; }
}
