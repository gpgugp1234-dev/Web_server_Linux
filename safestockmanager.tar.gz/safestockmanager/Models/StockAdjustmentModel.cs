namespace SafeStockManager.Web.Models;

public sealed class StockAdjustmentModel
{
    public int ItemId { get; set; }
    public string ItemName { get; set; } = string.Empty;
    public string? ItemCode { get; set; }
    public int CurrentQty { get; set; }
    public int ExcludedQty { get; set; }
    public int NewCurrentQty { get; set; }
    public int NewExcludedQty { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string CheckedBy { get; set; } = string.Empty;
    public DateTime ActionDate { get; set; } = DateTime.Today;
    public string? Memo { get; set; }
}
