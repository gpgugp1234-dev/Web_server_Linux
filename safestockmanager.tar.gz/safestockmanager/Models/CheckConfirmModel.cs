namespace SafeStockManager.Web.Models;

public sealed class CheckConfirmModel
{
    public List<int> ItemIds { get; set; } = [];
    public string CheckedBy { get; set; } = string.Empty;
    public DateTime ActionDate { get; set; } = DateTime.Today;
    public string Reason { get; set; } = "정기 재고조사";
    public string? Memo { get; set; }
}
