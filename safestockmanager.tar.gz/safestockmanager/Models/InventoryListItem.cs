namespace SafeStockManager.Web.Models;

public sealed class InventoryListItem
{
    public int ItemId { get; set; }
    public string? ItemCode { get; set; }
    public string ItemName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public string UnitName { get; set; } = string.Empty;
    public int SafetyStock { get; set; }
    public int AlertBufferQty { get; set; }
    public int CurrentQty { get; set; }
    public int ExcludedQty { get; set; }
    public int UsableQty { get; set; }
    public string StatusCode { get; set; } = "정상";
    public DateTime? LastChangedAt { get; set; }
    public DateTime? LastCheckedAt { get; set; }
    public string? LastCheckedBy { get; set; }
    public string? LastChangeReason { get; set; }
    public string? Location { get; set; }
    public string? Note { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsLongNotChecked { get; set; }

    public string CheckStatus => IsLongNotChecked ? "장기미점검" : "정상";
}
