namespace SafeStockManager.Web.Models;

public sealed class LookupItem
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int SortOrder { get; set; }

    public override string ToString() => Name;
}
