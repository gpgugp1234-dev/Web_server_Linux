namespace SafeStockManager.Web.Models;

public sealed class InventoryHistoryItem
{
    public int Id { get; set; }
    public int ItemId { get; set; }
    public string ItemName { get; set; } = string.Empty;
    public string? ItemCode { get; set; }
    public string ActionType { get; set; } = string.Empty;
    public int BeforeQty { get; set; }
    public int ChangedQty { get; set; }
    public int AfterQty { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string CheckedBy { get; set; } = string.Empty;
    public DateTime ActionDate { get; set; }
    public string? Memo { get; set; }
}
