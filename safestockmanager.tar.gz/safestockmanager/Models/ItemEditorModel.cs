namespace SafeStockManager.Web.Models;

public sealed class ItemEditorModel
{
    public int Id { get; set; }
    public string? ItemCode { get; set; }
    public string ItemName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public int UnitId { get; set; }
    public int SafetyStock { get; set; }
    public int AlertBufferQty { get; set; }
    public string? Location { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Note { get; set; }
}
