namespace SafeStockManager.Web.Models;

public sealed class Inspector
{
    public int Id { get; set; }
    public string InspectorName { get; set; } = string.Empty;
    public string? DeptName { get; set; }
    public bool IsActive { get; set; }

    public override string ToString()
    {
        return string.IsNullOrWhiteSpace(DeptName)
            ? InspectorName
            : $"{InspectorName} ({DeptName})";
    }
}
