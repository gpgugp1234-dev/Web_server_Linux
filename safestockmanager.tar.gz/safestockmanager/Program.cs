using Microsoft.AspNetCore.HttpOverrides;
using SafeStockManager.Web.Components;
using SafeStockManager.Web.Data;
using SafeStockManager.Web.Repositories;
using SafeStockManager.Web.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

string connectionString =
    builder.Configuration.GetConnectionString("InventoryDb")
    ?? builder.Configuration["ConnectionStrings:InventoryDb"]
    ?? throw new InvalidOperationException("MariaDB 연결 문자열(ConnectionStrings:InventoryDb)이 없습니다.");

builder.Services.AddSingleton(new DatabaseInitializer(connectionString));
builder.Services.AddScoped(_ => new InventoryRepository(connectionString));
builder.Services.AddScoped<AlertService>();
builder.Services.AddScoped<InventoryAppService>();
builder.Services.AddScoped<AdjustmentUnlockState>();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var database = scope.ServiceProvider.GetRequiredService<DatabaseInitializer>();
    database.Initialize();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
});

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();