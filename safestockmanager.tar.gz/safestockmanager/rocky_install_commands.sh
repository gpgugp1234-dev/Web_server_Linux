#!/usr/bin/env bash
set -euo pipefail

BASE_DIR=/opt/safestockmanager
SRC_ZIP=${1:-/root/SafeStockManager.Web.zip}
APP_NAME=SafeStockManager.Web
SERVICE_NAME=safestockmanager
APP_PORT=5095

sudo mkdir -p "$BASE_DIR/src" "$BASE_DIR/backup" /var/lib/safestockmanager
cd "$BASE_DIR/src"

TS=$(date +%Y%m%d_%H%M%S)
if [ -d "$APP_NAME" ]; then
  sudo cp -a "$APP_NAME" "$BASE_DIR/backup/${APP_NAME}_$TS"
fi

sudo unzip -o "$SRC_ZIP" -d "$BASE_DIR/src"
cd "$BASE_DIR/src/$APP_NAME"

sudo /usr/bin/dotnet restore
sudo /usr/bin/dotnet build -c Release
sudo /usr/bin/dotnet publish -c Release -o "$BASE_DIR/app"

sudo chown -R apache:apache /var/lib/safestockmanager "$BASE_DIR/app"

sudo tee /etc/systemd/system/${SERVICE_NAME}.service >/dev/null <<EOF
[Unit]
Description=SafeStockManager Web
After=network.target

[Service]
WorkingDirectory=$BASE_DIR/app
ExecStart=/usr/bin/dotnet $BASE_DIR/app/SafeStockManager.Web.dll --urls http://127.0.0.1:${APP_PORT}
Restart=always
RestartSec=3
SyslogIdentifier=${SERVICE_NAME}
User=apache
Environment=ASPNETCORE_ENVIRONMENT=Production

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now ${SERVICE_NAME}
sudo systemctl status ${SERVICE_NAME} --no-pager || true
sudo journalctl -u ${SERVICE_NAME} -n 100 --no-pager || true
