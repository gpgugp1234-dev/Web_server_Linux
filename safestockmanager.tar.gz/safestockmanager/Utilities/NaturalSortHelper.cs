using System.Text;
using System.Text.RegularExpressions;

namespace SafeStockManager.Web.Utilities;

public static partial class NaturalSortHelper
{
    public static string BuildSortKey(string? itemCode, string itemName)
    {
        string source = string.IsNullOrWhiteSpace(itemCode)
            ? itemName
            : $"{itemCode} {itemName}";
        source = Normalize(source);
        return TokenRegex().Replace(source, static match =>
        {
            if (int.TryParse(match.Value, out int number))
            {
                return number.ToString("D10");
            }

            return match.Value.ToUpperInvariant();
        });
    }

    public static string Normalize(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return string.Empty;
        }

        value = value.Trim();
        value = Regex.Replace(value, @"\s+", " ");
        return value;
    }

    [GeneratedRegex(@"\d+|\D+")]
    private static partial Regex TokenRegex();
}
