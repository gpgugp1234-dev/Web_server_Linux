using MySqlConnector;
using SafeStockManager.Web.Utilities;

namespace SafeStockManager.Web.Data;

public sealed class DatabaseInitializer
{
    private readonly string _connectionString;

    public DatabaseInitializer(string connectionString)
    {
        _connectionString = connectionString;
    }

    public void Initialize()
    {
        using var connection = new MySqlConnection(_connectionString);
        connection.Open();

        using var command = connection.CreateCommand();
        command.CommandText = @"
CREATE TABLE IF NOT EXISTS Categories (
    Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL,
    SortOrder INT NOT NULL DEFAULT 0,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY UX_Categories_CategoryName (CategoryName)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Units (
    Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    UnitName VARCHAR(50) NOT NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY UX_Units_UnitName (UnitName)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Inspectors (
    Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    InspectorName VARCHAR(100) NOT NULL,
    DeptName VARCHAR(100) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedAt DATETIME NOT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Items (
    Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ItemCode VARCHAR(100) NULL,
    ItemName VARCHAR(200) NOT NULL,
    SortKey VARCHAR(255) NOT NULL,
    CategoryId INT NOT NULL,
    UnitId INT NOT NULL,
    SafetyStock INT NOT NULL DEFAULT 0,
    AlertBufferQty INT NOT NULL DEFAULT 0,
    Location VARCHAR(200) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    Note TEXT NULL,
    CreatedAt DATETIME NOT NULL,
    CreatedBy VARCHAR(100) NOT NULL,
    UpdatedAt DATETIME NOT NULL,
    UpdatedBy VARCHAR(100) NOT NULL,
    CONSTRAINT FK_Items_Categories FOREIGN KEY (CategoryId) REFERENCES Categories(Id),
    CONSTRAINT FK_Items_Units FOREIGN KEY (UnitId) REFERENCES Units(Id),
    UNIQUE KEY UX_Items_ItemCode (ItemCode)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS InventoryStatus (
    ItemId INT NOT NULL PRIMARY KEY,
    CurrentQty INT NOT NULL DEFAULT 0,
    ExcludedQty INT NOT NULL DEFAULT 0,
    UsableQty INT NOT NULL DEFAULT 0,
    StatusCode VARCHAR(50) NOT NULL DEFAULT '정상',
    LastChangedAt DATETIME NULL,
    LastCheckedAt DATETIME NULL,
    LastCheckedBy VARCHAR(100) NULL,
    LastChangeReason VARCHAR(255) NULL,
    UpdatedAt DATETIME NOT NULL,
    CONSTRAINT FK_InventoryStatus_Items FOREIGN KEY (ItemId) REFERENCES Items(Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS InventoryHistory (
    Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ItemId INT NOT NULL,
    ActionType VARCHAR(50) NOT NULL,
    BeforeQty INT NOT NULL,
    ChangedQty INT NOT NULL,
    AfterQty INT NOT NULL,
    Reason VARCHAR(255) NOT NULL,
    CheckedBy VARCHAR(100) NOT NULL,
    ActionDate DATETIME NOT NULL,
    Memo TEXT NULL,
    CreatedAt DATETIME NOT NULL,
    CONSTRAINT FK_InventoryHistory_Items FOREIGN KEY (ItemId) REFERENCES Items(Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
";
        command.ExecuteNonQuery();

        SeedLookups(connection);
        SeedSampleData(connection);
    }

    private static void SeedLookups(MySqlConnection connection)
    {
        var categories = new[]
        {
            ("서식류", 1),
            ("박스류", 2),
            ("식별표류", 3),
            ("기자재류", 4),
            ("기타포장재류", 5),
            ("소모품류", 6)
        };

        foreach (var (name, sortOrder) in categories)
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = "INSERT IGNORE INTO Categories (CategoryName, SortOrder, IsActive) VALUES (@name, @sort, 1);";
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@sort", sortOrder);
            cmd.ExecuteNonQuery();
        }

        var units = new[] { "EA", "장", "개", "롤" };
        foreach (var unit in units)
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = "INSERT IGNORE INTO Units (UnitName, IsActive) VALUES (@name, 1);";
            cmd.Parameters.AddWithValue("@name", unit);
            cmd.ExecuteNonQuery();
        }

        using var inspectorCmd = connection.CreateCommand();
        inspectorCmd.CommandText = @"
INSERT INTO Inspectors (InspectorName, DeptName, IsActive, CreatedAt)
SELECT '황우진 대리', '포장팀', 1, @createdAt
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM Inspectors WHERE InspectorName = '황우진 대리');
";
        inspectorCmd.Parameters.AddWithValue("@createdAt", DateTime.Now);
        inspectorCmd.ExecuteNonQuery();
    }

    private static void SeedSampleData(MySqlConnection connection)
    {
        using var countCmd = connection.CreateCommand();
        countCmd.CommandText = "SELECT COUNT(*) FROM Items;";
        var existingCount = Convert.ToInt32(countCmd.ExecuteScalar());
        if (existingCount > 0)
        {
            return;
        }

        DateTime now = new(2026, 3, 26, 9, 0, 0);
        var samples = new[]
        {
            new SeedItem("FORM-DAILY-01", "포장일보 일반본", "서식류", "장", 20, 10, "문서 캐비닛", 2, 0, "초기 데이터", "황우진 대리", "업로드 텍스트 기준 샘플"),
            new SeedItem("FORM-DAILY-02", "포장일보 결재본", "서식류", "장", 10, 10, "문서 캐비닛", 0, 0, "초기 데이터", "황우진 대리", "업로드 텍스트 기준 샘플"),
            new SeedItem("FORM-QC-01", "완제품 검사대장 일반본", "서식류", "장", 20, 10, "문서 캐비닛", 51, 0, "초기 데이터", "황우진 대리", "업로드 텍스트 기준 샘플"),
            new SeedItem("BOX-CM424E10", "CM424E10", "박스류", "EA", 50, 20, "포장장", 145, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("BOX-SC13", "SC13", "박스류", "EA", 20, 10, "포장장", 31, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("BOX-SC10", "SC10", "박스류", "EA", 20, 10, "포장장", 40, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("BOX-CM448E03", "CM448E03 소형 박스", "박스류", "개", 5, 5, "포장장", 4, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("BOX-13", "13호 박스", "기타포장재류", "EA", 100, 30, "포장장", 430, 14, "초기 데이터", "황우진 대리", "실사용 제외 14개 반영"),
            new SeedItem("LABEL-81738-24210-5-P", "81738-24210-5 부품식별표", "식별표류", "EA", 500, 200, "캐비닛", 1270, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("LABEL-81738-24210-5-M", "81738-24210-5 공정이동 식별표", "식별표류", "EA", 100, 50, "캐비닛", 0, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("MAT-RIBBON", "포장용 바코드 프린터 용지", "기자재류", "롤", 5, 2, "B포장장", 6, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("MAT-REMOVER", "B포장장용 화이트 리무버", "기자재류", "개", 3, 2, "B포장장", 0, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("TRAY-A", "A단프라", "기타포장재류", "EA", 10, 5, "포장장", 8, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("BOX-LIHAN", "선별 전용 리한 박스", "기타포장재류", "EA", 20, 10, "포장장", 14, 0, "초기 데이터", "황우진 대리", null),
            new SeedItem("SUPPLY-BAG", "대용량 분리수거용 비닐 (흰색)", "소모품류", "장", 5, 2, "3층", 4, 0, "초기 데이터", "황우진 대리", null)
        };

        foreach (var sample in samples)
        {
            int categoryId = GetLookupId(connection, "Categories", "CategoryName", sample.CategoryName);
            int unitId = GetLookupId(connection, "Units", "UnitName", sample.UnitName);
            string sortKey = NaturalSortHelper.BuildSortKey(sample.ItemCode, sample.ItemName);

            using var itemCmd = connection.CreateCommand();
            itemCmd.CommandText = @"
INSERT INTO Items
(ItemCode, ItemName, SortKey, CategoryId, UnitId, SafetyStock, AlertBufferQty, Location, IsActive, Note, CreatedAt, CreatedBy, UpdatedAt, UpdatedBy)
VALUES
(@itemCode, @itemName, @sortKey, @categoryId, @unitId, @safetyStock, @alertBufferQty, @location, 1, @note, @createdAt, @createdBy, @updatedAt, @updatedBy);
SELECT LAST_INSERT_ID();
";
            itemCmd.Parameters.AddWithValue("@itemCode", (object?)sample.ItemCode ?? DBNull.Value);
            itemCmd.Parameters.AddWithValue("@itemName", sample.ItemName);
            itemCmd.Parameters.AddWithValue("@sortKey", sortKey);
            itemCmd.Parameters.AddWithValue("@categoryId", categoryId);
            itemCmd.Parameters.AddWithValue("@unitId", unitId);
            itemCmd.Parameters.AddWithValue("@safetyStock", sample.SafetyStock);
            itemCmd.Parameters.AddWithValue("@alertBufferQty", sample.AlertBufferQty);
            itemCmd.Parameters.AddWithValue("@location", (object?)sample.Location ?? DBNull.Value);
            itemCmd.Parameters.AddWithValue("@note", (object?)sample.Note ?? DBNull.Value);
            itemCmd.Parameters.AddWithValue("@createdAt", now);
            itemCmd.Parameters.AddWithValue("@createdBy", sample.Actor);
            itemCmd.Parameters.AddWithValue("@updatedAt", now);
            itemCmd.Parameters.AddWithValue("@updatedBy", sample.Actor);

            int itemId = Convert.ToInt32(itemCmd.ExecuteScalar());

            int usableQty = sample.CurrentQty - sample.ExcludedQty;
            string status = usableQty <= 0 ? "품절" :
                            usableQty <= sample.SafetyStock ? "긴급" :
                            usableQty <= sample.SafetyStock + sample.AlertBufferQty ? "주의" :
                            "정상";

            using var statusCmd = connection.CreateCommand();
            statusCmd.CommandText = @"
INSERT INTO InventoryStatus
(ItemId, CurrentQty, ExcludedQty, UsableQty, StatusCode, LastChangedAt, LastCheckedAt, LastCheckedBy, LastChangeReason, UpdatedAt)
VALUES
(@itemId, @currentQty, @excludedQty, @usableQty, @statusCode, @lastChangedAt, @lastCheckedAt, @lastCheckedBy, @lastChangeReason, @updatedAt);
";
            statusCmd.Parameters.AddWithValue("@itemId", itemId);
            statusCmd.Parameters.AddWithValue("@currentQty", sample.CurrentQty);
            statusCmd.Parameters.AddWithValue("@excludedQty", sample.ExcludedQty);
            statusCmd.Parameters.AddWithValue("@usableQty", usableQty);
            statusCmd.Parameters.AddWithValue("@statusCode", status);
            statusCmd.Parameters.AddWithValue("@lastChangedAt", now);
            statusCmd.Parameters.AddWithValue("@lastCheckedAt", now);
            statusCmd.Parameters.AddWithValue("@lastCheckedBy", sample.Actor);
            statusCmd.Parameters.AddWithValue("@lastChangeReason", sample.Reason);
            statusCmd.Parameters.AddWithValue("@updatedAt", now);
            statusCmd.ExecuteNonQuery();

            using var historyCmd = connection.CreateCommand();
            historyCmd.CommandText = @"
INSERT INTO InventoryHistory
(ItemId, ActionType, BeforeQty, ChangedQty, AfterQty, Reason, CheckedBy, ActionDate, Memo, CreatedAt)
VALUES
(@itemId, '신규등록', 0, @afterQty, @afterQty, @reason, @checkedBy, @actionDate, @memo, @createdAt);
";
            historyCmd.Parameters.AddWithValue("@itemId", itemId);
            historyCmd.Parameters.AddWithValue("@afterQty", sample.CurrentQty);
            historyCmd.Parameters.AddWithValue("@reason", sample.Reason);
            historyCmd.Parameters.AddWithValue("@checkedBy", sample.Actor);
            historyCmd.Parameters.AddWithValue("@actionDate", now);
            historyCmd.Parameters.AddWithValue("@memo", (object?)sample.Note ?? DBNull.Value);
            historyCmd.Parameters.AddWithValue("@createdAt", now);
            historyCmd.ExecuteNonQuery();
        }
    }

    private static int GetLookupId(MySqlConnection connection, string tableName, string columnName, string value)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = $"SELECT Id FROM {tableName} WHERE {columnName} = @value LIMIT 1;";
        cmd.Parameters.AddWithValue("@value", value);

        object? result = cmd.ExecuteScalar();
        if (result is null || result == DBNull.Value)
        {
            throw new InvalidOperationException($"{tableName} lookup not found: {value}");
        }

        return Convert.ToInt32(result);
    }

    private sealed record SeedItem(
        string? ItemCode,
        string ItemName,
        string CategoryName,
        string UnitName,
        int SafetyStock,
        int AlertBufferQty,
        string? Location,
        int CurrentQty,
        int ExcludedQty,
        string Reason,
        string Actor,
        string? Note);
}
