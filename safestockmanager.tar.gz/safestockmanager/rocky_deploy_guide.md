# SafeStockManager.Web Rocky 배포 가이드 (MariaDB)

## 1) MariaDB DB/계정 준비

```sql
CREATE DATABASE safestockmanager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'safestock_app'@'127.0.0.1' IDENTIFIED BY '강한비밀번호로변경';
GRANT ALL PRIVILEGES ON safestockmanager.* TO 'safestock_app'@'127.0.0.1';
FLUSH PRIVILEGES;
```

## 2) appsettings.Production.json 수정

`ConnectionStrings:InventoryDb` 값을 실제 MariaDB 접속정보로 바꿉니다.

예시:

```json
{
  "ConnectionStrings": {
    "InventoryDb": "Server=127.0.0.1;Port=3306;Database=safestockmanager;User ID=safestock_app;Password=실제비밀번호;CharSet=utf8mb4;SslMode=None;Allow User Variables=true;"
  }
}
```

## 3) 빌드/배포

```bash
cd /opt/safestockmanager/src/SafeStockManager.Web
dotnet restore
dotnet build -c Release
dotnet publish -c Release -o /opt/safestockmanager/app
```

## 4) systemd 서비스

```ini
[Unit]
Description=SafeStockManager Web
After=network.target mariadb.service

[Service]
WorkingDirectory=/opt/safestockmanager/app
ExecStart=/usr/bin/dotnet /opt/safestockmanager/app/SafeStockManager.Web.dll
Restart=always
RestartSec=3
User=root
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=ASPNETCORE_URLS=http://127.0.0.1:5095

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable --now safestockmanager.service
systemctl status safestockmanager.service --no-pager
```

## 5) Apache Reverse Proxy 예시

```apache
ProxyPreserveHost On
ProxyPass / http://127.0.0.1:5095/
ProxyPassReverse / http://127.0.0.1:5095/
RequestHeader set X-Forwarded-Proto "http"
```

HTTPS 종단이면 `X-Forwarded-Proto "https"` 로 맞춥니다.
