using MySqlConnector;
using SafeStockManager.Web.Models;
using SafeStockManager.Web.Services;
using SafeStockManager.Web.Utilities;

namespace SafeStockManager.Web.Repositories;

public sealed class InventoryRepository
{
    private readonly string _connectionString;

    public InventoryRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public List<LookupItem> GetCategories()
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"SELECT Id, CategoryName, SortOrder FROM Categories WHERE IsActive = 1 ORDER BY SortOrder, CategoryName;";
        using var reader = cmd.ExecuteReader();

        var list = new List<LookupItem>();
        while (reader.Read())
        {
            list.Add(new LookupItem
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                SortOrder = reader.GetInt32(2)
            });
        }

        return list;
    }

    public List<LookupItem> GetUnits()
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"SELECT Id, UnitName FROM Units WHERE IsActive = 1 ORDER BY UnitName;";
        using var reader = cmd.ExecuteReader();

        var list = new List<LookupItem>();
        while (reader.Read())
        {
            list.Add(new LookupItem
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                SortOrder = 0
            });
        }

        return list;
    }

    public List<Inspector> GetInspectors(bool includeInactive = false)
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = $@"
SELECT Id, InspectorName, DeptName, IsActive
FROM Inspectors
{(includeInactive ? string.Empty : "WHERE IsActive = 1")}
ORDER BY IsActive DESC, InspectorName;
";
        using var reader = cmd.ExecuteReader();

        var list = new List<Inspector>();
        while (reader.Read())
        {
            list.Add(new Inspector
            {
                Id = reader.GetInt32(0),
                InspectorName = reader.GetString(1),
                DeptName = reader.IsDBNull(2) ? null : reader.GetString(2),
                IsActive = reader.GetInt32(3) == 1
            });
        }

        return list;
    }

    public List<InventoryListItem> GetInventoryItems(bool includeInactive)
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = $@"
SELECT 
    i.Id,
    i.ItemCode,
    i.ItemName,
    c.CategoryName,
    u.UnitName,
    i.SafetyStock,
    i.AlertBufferQty,
    s.CurrentQty,
    s.ExcludedQty,
    s.UsableQty,
    s.StatusCode,
    s.LastChangedAt,
    s.LastCheckedAt,
    s.LastCheckedBy,
    s.LastChangeReason,
    i.Location,
    i.Note,
    i.IsActive
FROM Items i
JOIN Categories c ON c.Id = i.CategoryId
JOIN Units u ON u.Id = i.UnitId
JOIN InventoryStatus s ON s.ItemId = i.Id
{(includeInactive ? string.Empty : "WHERE i.IsActive = 1")}
ORDER BY i.IsActive DESC, c.SortOrder ASC, i.SortKey ASC, COALESCE(i.ItemCode, ''), i.ItemName;
";

        using var reader = cmd.ExecuteReader();
        var list = new List<InventoryListItem>();

        while (reader.Read())
        {
            list.Add(new InventoryListItem
            {
                ItemId = reader.GetInt32(0),
                ItemCode = reader.IsDBNull(1) ? null : reader.GetString(1),
                ItemName = reader.GetString(2),
                CategoryName = reader.GetString(3),
                UnitName = reader.GetString(4),
                SafetyStock = reader.GetInt32(5),
                AlertBufferQty = reader.GetInt32(6),
                CurrentQty = reader.GetInt32(7),
                ExcludedQty = reader.GetInt32(8),
                UsableQty = reader.GetInt32(9),
                StatusCode = reader.GetString(10),
                LastChangedAt = ParseNullableDateTime(reader, 11),
                LastCheckedAt = ParseNullableDateTime(reader, 12),
                LastCheckedBy = reader.IsDBNull(13) ? null : reader.GetString(13),
                LastChangeReason = reader.IsDBNull(14) ? null : reader.GetString(14),
                Location = reader.IsDBNull(15) ? null : reader.GetString(15),
                Note = reader.IsDBNull(16) ? null : reader.GetString(16),
                IsActive = reader.GetInt32(17) == 1
            });
        }

        return list;
    }

    public ItemEditorModel? GetItemEditorModel(int itemId)
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
SELECT Id, ItemCode, ItemName, CategoryId, UnitId, SafetyStock, AlertBufferQty, Location, IsActive, Note
FROM Items
WHERE Id = @id;
";
        cmd.Parameters.AddWithValue("@id", itemId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }

        return new ItemEditorModel
        {
            Id = reader.GetInt32(0),
            ItemCode = reader.IsDBNull(1) ? null : reader.GetString(1),
            ItemName = reader.GetString(2),
            CategoryId = reader.GetInt32(3),
            UnitId = reader.GetInt32(4),
            SafetyStock = reader.GetInt32(5),
            AlertBufferQty = reader.GetInt32(6),
            Location = reader.IsDBNull(7) ? null : reader.GetString(7),
            IsActive = reader.GetInt32(8) == 1,
            Note = reader.IsDBNull(9) ? null : reader.GetString(9)
        };
    }

    public void SaveItem(ItemEditorModel model, string actor)
    {
        using var connection = CreateOpenConnection();
        using var transaction = connection.BeginTransaction();

        EnsureNoDuplicateItem(connection, transaction, model);

        string now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        string sortKey = NaturalSortHelper.BuildSortKey(model.ItemCode, model.ItemName);

        if (model.Id == 0)
        {
            using var cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            cmd.CommandText = @"
INSERT INTO Items
(ItemCode, ItemName, SortKey, CategoryId, UnitId, SafetyStock, AlertBufferQty, Location, IsActive, Note, CreatedAt, CreatedBy, UpdatedAt, UpdatedBy)
VALUES
(@itemCode, @itemName, @sortKey, @categoryId, @unitId, @safetyStock, @alertBufferQty, @location, @isActive, @note, @createdAt, @createdBy, @updatedAt, @updatedBy);
SELECT LAST_INSERT_ID();
";
            cmd.Parameters.AddWithValue("@itemCode", (object?)NullIfEmpty(model.ItemCode) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@itemName", model.ItemName.Trim());
            cmd.Parameters.AddWithValue("@sortKey", sortKey);
            cmd.Parameters.AddWithValue("@categoryId", model.CategoryId);
            cmd.Parameters.AddWithValue("@unitId", model.UnitId);
            cmd.Parameters.AddWithValue("@safetyStock", model.SafetyStock);
            cmd.Parameters.AddWithValue("@alertBufferQty", model.AlertBufferQty);
            cmd.Parameters.AddWithValue("@location", (object?)NullIfEmpty(model.Location) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@isActive", model.IsActive ? 1 : 0);
            cmd.Parameters.AddWithValue("@note", (object?)NullIfEmpty(model.Note) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@createdAt", now);
            cmd.Parameters.AddWithValue("@createdBy", actor);
            cmd.Parameters.AddWithValue("@updatedAt", now);
            cmd.Parameters.AddWithValue("@updatedBy", actor);

            int itemId = Convert.ToInt32(cmd.ExecuteScalar());

            using var statusCmd = connection.CreateCommand();
            statusCmd.Transaction = transaction;
            statusCmd.CommandText = @"
INSERT INTO InventoryStatus
(ItemId, CurrentQty, ExcludedQty, UsableQty, StatusCode, LastChangedAt, LastCheckedAt, LastCheckedBy, LastChangeReason, UpdatedAt)
VALUES
(@itemId, 0, 0, 0, '품절', NULL, NULL, NULL, NULL, @updatedAt);
";
            statusCmd.Parameters.AddWithValue("@itemId", itemId);
            statusCmd.Parameters.AddWithValue("@updatedAt", now);
            statusCmd.ExecuteNonQuery();

            using var historyCmd = connection.CreateCommand();
            historyCmd.Transaction = transaction;
            historyCmd.CommandText = @"
INSERT INTO InventoryHistory
(ItemId, ActionType, BeforeQty, ChangedQty, AfterQty, Reason, CheckedBy, ActionDate, Memo, CreatedAt)
VALUES
(@itemId, '신규등록', 0, 0, 0, '신규 품목 등록', @checkedBy, @actionDate, @memo, @createdAt);
";
            historyCmd.Parameters.AddWithValue("@itemId", itemId);
            historyCmd.Parameters.AddWithValue("@checkedBy", actor);
            historyCmd.Parameters.AddWithValue("@actionDate", now);
            historyCmd.Parameters.AddWithValue("@memo", (object?)NullIfEmpty(model.Note) ?? DBNull.Value);
            historyCmd.Parameters.AddWithValue("@createdAt", now);
            historyCmd.ExecuteNonQuery();
        }
        else
        {
            using var cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            cmd.CommandText = @"
UPDATE Items
SET
    ItemCode = @itemCode,
    ItemName = @itemName,
    SortKey = @sortKey,
    CategoryId = @categoryId,
    UnitId = @unitId,
    SafetyStock = @safetyStock,
    AlertBufferQty = @alertBufferQty,
    Location = @location,
    IsActive = @isActive,
    Note = @note,
    UpdatedAt = @updatedAt,
    UpdatedBy = @updatedBy
WHERE Id = @id;
";
            cmd.Parameters.AddWithValue("@id", model.Id);
            cmd.Parameters.AddWithValue("@itemCode", (object?)NullIfEmpty(model.ItemCode) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@itemName", model.ItemName.Trim());
            cmd.Parameters.AddWithValue("@sortKey", sortKey);
            cmd.Parameters.AddWithValue("@categoryId", model.CategoryId);
            cmd.Parameters.AddWithValue("@unitId", model.UnitId);
            cmd.Parameters.AddWithValue("@safetyStock", model.SafetyStock);
            cmd.Parameters.AddWithValue("@alertBufferQty", model.AlertBufferQty);
            cmd.Parameters.AddWithValue("@location", (object?)NullIfEmpty(model.Location) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@isActive", model.IsActive ? 1 : 0);
            cmd.Parameters.AddWithValue("@note", (object?)NullIfEmpty(model.Note) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@updatedAt", now);
            cmd.Parameters.AddWithValue("@updatedBy", actor);
            cmd.ExecuteNonQuery();

            RecalculateStatus(connection, transaction, model.Id, new AlertService(), updateCheckFields: false);
        }

        transaction.Commit();
    }

    public void AdjustStock(StockAdjustmentModel model, AlertService alertService)
    {
        using var connection = CreateOpenConnection();
        using var transaction = connection.BeginTransaction();

        var current = GetStatusRow(connection, transaction, model.ItemId);

        int usableQty = model.NewCurrentQty - model.NewExcludedQty;
        if (usableQty < 0)
        {
            throw new InvalidOperationException("실사용가능재고가 음수가 되지 않도록 확인해 주세요.");
        }

        var itemPolicy = GetItemPolicy(connection, transaction, model.ItemId);
        string status = alertService.DetermineStatus(usableQty, itemPolicy.SafetyStock, itemPolicy.AlertBufferQty);
        string actionDate = model.ActionDate.ToString("yyyy-MM-dd HH:mm:ss");
        int changedQty = model.NewCurrentQty - current.CurrentQty;

        using var statusCmd = connection.CreateCommand();
        statusCmd.Transaction = transaction;
        statusCmd.CommandText = @"
UPDATE InventoryStatus
SET
    CurrentQty = @currentQty,
    ExcludedQty = @excludedQty,
    UsableQty = @usableQty,
    StatusCode = @statusCode,
    LastChangedAt = @lastChangedAt,
    LastCheckedAt = @lastCheckedAt,
    LastCheckedBy = @lastCheckedBy,
    LastChangeReason = @lastChangeReason,
    UpdatedAt = @updatedAt
WHERE ItemId = @itemId;
";
        statusCmd.Parameters.AddWithValue("@currentQty", model.NewCurrentQty);
        statusCmd.Parameters.AddWithValue("@excludedQty", model.NewExcludedQty);
        statusCmd.Parameters.AddWithValue("@usableQty", usableQty);
        statusCmd.Parameters.AddWithValue("@statusCode", status);
        statusCmd.Parameters.AddWithValue("@lastChangedAt", actionDate);
        statusCmd.Parameters.AddWithValue("@lastCheckedAt", actionDate);
        statusCmd.Parameters.AddWithValue("@lastCheckedBy", model.CheckedBy);
        statusCmd.Parameters.AddWithValue("@lastChangeReason", model.Reason.Trim());
        statusCmd.Parameters.AddWithValue("@updatedAt", actionDate);
        statusCmd.Parameters.AddWithValue("@itemId", model.ItemId);
        statusCmd.ExecuteNonQuery();

        using var historyCmd = connection.CreateCommand();
        historyCmd.Transaction = transaction;
        historyCmd.CommandText = @"
INSERT INTO InventoryHistory
(ItemId, ActionType, BeforeQty, ChangedQty, AfterQty, Reason, CheckedBy, ActionDate, Memo, CreatedAt)
VALUES
(@itemId, '재고보정', @beforeQty, @changedQty, @afterQty, @reason, @checkedBy, @actionDate, @memo, @createdAt);
";
        historyCmd.Parameters.AddWithValue("@itemId", model.ItemId);
        historyCmd.Parameters.AddWithValue("@beforeQty", current.CurrentQty);
        historyCmd.Parameters.AddWithValue("@changedQty", changedQty);
        historyCmd.Parameters.AddWithValue("@afterQty", model.NewCurrentQty);
        historyCmd.Parameters.AddWithValue("@reason", model.Reason.Trim());
        historyCmd.Parameters.AddWithValue("@checkedBy", model.CheckedBy);
        historyCmd.Parameters.AddWithValue("@actionDate", actionDate);
        historyCmd.Parameters.AddWithValue("@memo", (object?)NullIfEmpty(model.Memo) ?? DBNull.Value);
        historyCmd.Parameters.AddWithValue("@createdAt", actionDate);
        historyCmd.ExecuteNonQuery();

        transaction.Commit();
    }

    public void ConfirmCheck(CheckConfirmModel model)
    {
        using var connection = CreateOpenConnection();
        using var transaction = connection.BeginTransaction();

        string actionDate = model.ActionDate.ToString("yyyy-MM-dd HH:mm:ss");

        foreach (int itemId in model.ItemIds.Distinct())
        {
            var current = GetStatusRow(connection, transaction, itemId);

            using var statusCmd = connection.CreateCommand();
            statusCmd.Transaction = transaction;
            statusCmd.CommandText = @"
UPDATE InventoryStatus
SET
    LastCheckedAt = @lastCheckedAt,
    LastCheckedBy = @lastCheckedBy,
    UpdatedAt = @updatedAt
WHERE ItemId = @itemId;
";
            statusCmd.Parameters.AddWithValue("@lastCheckedAt", actionDate);
            statusCmd.Parameters.AddWithValue("@lastCheckedBy", model.CheckedBy);
            statusCmd.Parameters.AddWithValue("@updatedAt", actionDate);
            statusCmd.Parameters.AddWithValue("@itemId", itemId);
            statusCmd.ExecuteNonQuery();

            using var historyCmd = connection.CreateCommand();
            historyCmd.Transaction = transaction;
            historyCmd.CommandText = @"
INSERT INTO InventoryHistory
(ItemId, ActionType, BeforeQty, ChangedQty, AfterQty, Reason, CheckedBy, ActionDate, Memo, CreatedAt)
VALUES
(@itemId, '조사확인', @beforeQty, 0, @afterQty, @reason, @checkedBy, @actionDate, @memo, @createdAt);
";
            historyCmd.Parameters.AddWithValue("@itemId", itemId);
            historyCmd.Parameters.AddWithValue("@beforeQty", current.CurrentQty);
            historyCmd.Parameters.AddWithValue("@afterQty", current.CurrentQty);
            historyCmd.Parameters.AddWithValue("@reason", model.Reason.Trim());
            historyCmd.Parameters.AddWithValue("@checkedBy", model.CheckedBy);
            historyCmd.Parameters.AddWithValue("@actionDate", actionDate);
            historyCmd.Parameters.AddWithValue("@memo", (object?)NullIfEmpty(model.Memo) ?? DBNull.Value);
            historyCmd.Parameters.AddWithValue("@createdAt", actionDate);
            historyCmd.ExecuteNonQuery();
        }

        transaction.Commit();
    }

    public void SetItemActive(int itemId, bool isActive, string actor)
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
UPDATE Items
SET IsActive = @isActive, UpdatedAt = @updatedAt, UpdatedBy = @updatedBy
WHERE Id = @id;
";
        cmd.Parameters.AddWithValue("@isActive", isActive ? 1 : 0);
        cmd.Parameters.AddWithValue("@updatedAt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("@updatedBy", actor);
        cmd.Parameters.AddWithValue("@id", itemId);
        cmd.ExecuteNonQuery();
    }

    public void SaveInspector(Inspector inspector)
    {
        using var connection = CreateOpenConnection();
        if (inspector.Id == 0)
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = @"
INSERT INTO Inspectors (InspectorName, DeptName, IsActive, CreatedAt)
VALUES (@name, @dept, @isActive, @createdAt);
";
            cmd.Parameters.AddWithValue("@name", inspector.InspectorName.Trim());
            cmd.Parameters.AddWithValue("@dept", (object?)NullIfEmpty(inspector.DeptName) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@isActive", inspector.IsActive ? 1 : 0);
            cmd.Parameters.AddWithValue("@createdAt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.ExecuteNonQuery();
        }
        else
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = @"
UPDATE Inspectors
SET InspectorName = @name, DeptName = @dept, IsActive = @isActive
WHERE Id = @id;
";
            cmd.Parameters.AddWithValue("@id", inspector.Id);
            cmd.Parameters.AddWithValue("@name", inspector.InspectorName.Trim());
            cmd.Parameters.AddWithValue("@dept", (object?)NullIfEmpty(inspector.DeptName) ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@isActive", inspector.IsActive ? 1 : 0);
            cmd.ExecuteNonQuery();
        }
    }

    public List<InventoryHistoryItem> GetHistory(int itemId)
    {
        using var connection = CreateOpenConnection();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
SELECT 
    h.Id,
    h.ItemId,
    i.ItemName,
    i.ItemCode,
    h.ActionType,
    h.BeforeQty,
    h.ChangedQty,
    h.AfterQty,
    h.Reason,
    h.CheckedBy,
    h.ActionDate,
    h.Memo
FROM InventoryHistory h
JOIN Items i ON i.Id = h.ItemId
WHERE h.ItemId = @itemId
ORDER BY h.ActionDate DESC, h.Id DESC;
";
        cmd.Parameters.AddWithValue("@itemId", itemId);

        using var reader = cmd.ExecuteReader();
        var list = new List<InventoryHistoryItem>();
        while (reader.Read())
        {
            list.Add(new InventoryHistoryItem
            {
                Id = reader.GetInt32(0),
                ItemId = reader.GetInt32(1),
                ItemName = reader.GetString(2),
                ItemCode = reader.IsDBNull(3) ? null : reader.GetString(3),
                ActionType = reader.GetString(4),
                BeforeQty = reader.GetInt32(5),
                ChangedQty = reader.GetInt32(6),
                AfterQty = reader.GetInt32(7),
                Reason = reader.GetString(8),
                CheckedBy = reader.GetString(9),
                ActionDate = DateTime.Parse(reader.GetString(10)),
                Memo = reader.IsDBNull(11) ? null : reader.GetString(11)
            });
        }

        return list;
    }

    private void EnsureNoDuplicateItem(MySqlConnection connection, MySqlTransaction transaction, ItemEditorModel model)
    {
        using var codeCmd = connection.CreateCommand();
        codeCmd.Transaction = transaction;
        codeCmd.CommandText = @"
SELECT COUNT(1)
FROM Items
WHERE Id <> @id
  AND COALESCE(ItemCode, '') <> ''
  AND ItemCode = @itemCode;
";
        codeCmd.Parameters.AddWithValue("@id", model.Id);
        codeCmd.Parameters.AddWithValue("@itemCode", (object?)NullIfEmpty(model.ItemCode) ?? DBNull.Value);

        if (!string.IsNullOrWhiteSpace(model.ItemCode))
        {
            int codeCount = Convert.ToInt32(codeCmd.ExecuteScalar());
            if (codeCount > 0)
            {
                throw new InvalidOperationException("동일한 품목코드가 이미 존재합니다.");
            }
        }

        using var nameCmd = connection.CreateCommand();
        nameCmd.Transaction = transaction;
        nameCmd.CommandText = @"
SELECT COUNT(1)
FROM Items
WHERE Id <> @id
  AND CategoryId = @categoryId
  AND ItemName = @itemName;
";
        nameCmd.Parameters.AddWithValue("@id", model.Id);
        nameCmd.Parameters.AddWithValue("@categoryId", model.CategoryId);
        nameCmd.Parameters.AddWithValue("@itemName", model.ItemName.Trim());

        int nameCount = Convert.ToInt32(nameCmd.ExecuteScalar());
        if (nameCount > 0)
        {
            throw new InvalidOperationException("동일 분류에 같은 품목명이 이미 존재합니다.");
        }
    }

    private void RecalculateStatus(MySqlConnection connection, MySqlTransaction transaction, int itemId, AlertService alertService, bool updateCheckFields)
    {
        var current = GetStatusRow(connection, transaction, itemId);
        var policy = GetItemPolicy(connection, transaction, itemId);
        int usableQty = current.CurrentQty - current.ExcludedQty;
        string status = alertService.DetermineStatus(usableQty, policy.SafetyStock, policy.AlertBufferQty);

        using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText = $@"
UPDATE InventoryStatus
SET
    UsableQty = @usableQty,
    StatusCode = @statusCode,
    UpdatedAt = @updatedAt
    {(updateCheckFields ? ", LastCheckedAt = @lastCheckedAt, LastCheckedBy = @lastCheckedBy" : string.Empty)}
WHERE ItemId = @itemId;
";
        cmd.Parameters.AddWithValue("@usableQty", usableQty);
        cmd.Parameters.AddWithValue("@statusCode", status);
        cmd.Parameters.AddWithValue("@updatedAt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        if (updateCheckFields)
        {
            cmd.Parameters.AddWithValue("@lastCheckedAt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@lastCheckedBy", "SYSTEM");
        }

        cmd.Parameters.AddWithValue("@itemId", itemId);
        cmd.ExecuteNonQuery();
    }

    private StatusRow GetStatusRow(MySqlConnection connection, MySqlTransaction transaction, int itemId)
    {
        using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText = @"SELECT CurrentQty, ExcludedQty, UsableQty, StatusCode FROM InventoryStatus WHERE ItemId = @itemId;";
        cmd.Parameters.AddWithValue("@itemId", itemId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read())
        {
            throw new InvalidOperationException("재고 상태를 찾을 수 없습니다.");
        }

        return new StatusRow(
            reader.GetInt32(0),
            reader.GetInt32(1),
            reader.GetInt32(2),
            reader.GetString(3));
    }

    private ItemPolicy GetItemPolicy(MySqlConnection connection, MySqlTransaction transaction, int itemId)
    {
        using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText = @"SELECT SafetyStock, AlertBufferQty FROM Items WHERE Id = @itemId;";
        cmd.Parameters.AddWithValue("@itemId", itemId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read())
        {
            throw new InvalidOperationException("품목 정책을 찾을 수 없습니다.");
        }

        return new ItemPolicy(reader.GetInt32(0), reader.GetInt32(1));
    }

    private static DateTime? ParseNullableDateTime(MySqlDataReader reader, int ordinal)
    {
        if (reader.IsDBNull(ordinal))
        {
            return null;
        }

        object value = reader.GetValue(ordinal);
        if (value is DateTime dateTime)
        {
            return dateTime;
        }

        return DateTime.Parse(Convert.ToString(value)!);
    }

    private MySqlConnection CreateOpenConnection()
    {
        var connection = new MySqlConnection(_connectionString);
        connection.Open();
        return connection;
    }

    private static string? NullIfEmpty(string? value)
    {
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }

    private sealed record StatusRow(int CurrentQty, int ExcludedQty, int UsableQty, string StatusCode);
    private sealed record ItemPolicy(int SafetyStock, int AlertBufferQty);
}
